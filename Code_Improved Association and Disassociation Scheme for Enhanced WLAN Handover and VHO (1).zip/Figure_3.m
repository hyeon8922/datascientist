clear all; close all; clc;
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
%   File name:      Fig_3_DIT.m                                           %
%   Last update:    April, 2016                                           %
%   Professor:     Jong-Moon Chung (Coressponding Author)                 %
%   Author:   Sungjin Shin, Donghyuk Han, Hyoungjun Cho                   %
%             Researcher / Engineer                                       %
%             Communications & Networking Lab (CNL)                       %
%             School of Electrical & Electronic Engineering               %
%             Yonsei University                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %
%% Path Loss
% Ref: Performance Evaluation of WLAN/Cellular Media Access for Mobile 
% Voice Users under Random Mobility Models
P_t=20;                             % Transmitted Power (dBm)
L=58.7;                             % Constant Path Loss (dB)
n=4;                                % Path Loss Exponent
d_0=1;                              % distance from the AP (m)
mu=0;                               % Mean of Gaussian RV
sigma=6;                            % Mean of Gaussian RV
v=2.5;                              % Velocity (m/s)
temp0 = 28.07;                      % P_t - L
session_setup = 1.253;              % session setup time
d=5:0.02:160; d=d';
temp1(:,1) = temp0 - 10*n*log10(d(:,1));
temp2(:,1) = power(10,(temp1(:,1)/10))*0.001;
P_r(:,1) = d(:,1);                  % distance from the AP
P_r(:,2) = 10*log10(temp2(:,1));    % RSSI
RS_dist(:,1)=[-60 -62 -64 -66 -68 -70 -72 -74];
RS_dist(:,2)=[28.3 31.76 35.64 39.98 44.86 50.34 56.48 63.36];

%% PS eq. (9)
rts=44*8;                             % RTS size (bits) 
cts=44*8;                             % CTS size (bits)  
data=1550*8;                          % DATA size (bits) 
sifs=10*10^(-6);                      % SIFS time (s) 
difs=20*100^(-6);                     % DIFS time (s)  
slot=20*10^(-6);                      % Slot time (s)  
rate=10*10^9;                         % data rate (bps)
ts=(rts+cts+data)/rate+3*sifs+difs;   % success time
tc=(rts+cts)/rate+sifs+difs;          % collision time
trcd=(rts+cts+data)/rate+2*sifs;      % Equation (6)
pe_rts = 0.1;                         % PER of RTS
pe_data = 0.95;                       % PER of data
W=32;                                 % Min CW 
m=7;                                  % Retry limit
for i=1
    x0 = [1; 1];
    n=15;                             % number of nodes
    % Equation for tau (probability that an UE transmits a RTS packet in a 
    % randomly chosen slot time and p (probability that a transmitted RTS 
    % packet encounters a collision
    [x(i,:),fval] = fsolve(@(x0)Bianchi_obfective_function(x0,n,W,m),x0);
    % conditional probability that at least one transmission occurs in a 
    % randomly chosen slot time
    ptr(i,1)=1-(1-x(i,1))^n;
    % conditional probability that this transmission is successful
    ps(i,1)=(n*x(i,1)*power(1-x(i,1),n-2))/ptr(i,1);
    % Equation (7)
    exp_slot(i,1)=ptr(i,1)*(1-ps(i,1))*tc + ptr(i,1)*(1-ptr(i,1))*tc ...
        + ptr(i,1)*ps(i,1)*pe_rts*tc + ptr(i,1)*ps(i,1)*(1-pe_rts) ...
        *pe_rts*tc + ptr(i,1)*ps(i,1)*(1-pe_rts)*(1-pe_rts) ...
        *pe_data*trcd;
end
pp=x(1,2);
for i=1:m
    backoff(i,1) = W/2 * 2^(i-1);
    backoff(i,2) = backoff(i,1) * (((pp^i)-(pp^(m+1))) / (1-pp^(m+1)))...
        *exp_slot(1,1);
end
avg_RTT = sum(backoff(:,2))*10^(-3);  
PS_DIT(:,1) = RS_dist(:,1);
PS_DIT(:,2) = avg_RTT + session_setup;

%% IEEE 802.11 [1] 
% Maximum disassociation time is 10 seconds by 802.11 std
Max_expire_time = 10;                 % Beacon expire (sec)
RSS_out(1,1)=-76;                   % IEEE 802.11 disassociation threshold
RSS_out(1,2)=71.1;                  % Distance when RSSI is -76 dBm
Exist_DIT(:,1) = RS_dist(:,1);      % Distance (m)
for i=1:size(RS_dist,1)
    Exist_DIT(i,1) = RS_dist(i,1);
    Exist_DIT(i,2) = ((RSS_out(1,2) - RS_dist(i,2)) / v) + session_setup;
    if Exist_DIT(i,2) > (Max_expire_time + session_setup)
        Exist_DIT(i,2) = (Max_expire_time + session_setup);
    end
end

%% RESHO [2]
for i=1:size(RS_dist,1)
    RESHO_DIT(i,1) = RS_dist(i,1);          % Distance
    % In RESHO, disassociation threshold is changed considering velocity 
    RESHO_DIT(i,2) = ((RSS_out(1,2) - RS_dist(i,2) - 6) / v);
    if RESHO_DIT(i,2) > (Max_expire_time + session_setup)
        RESHO_DIT(i,2) = (Max_expire_time + session_setup);
    elseif RESHO_DIT(i,2) - session_setup < 0
        RESHO_DIT(i,2) = session_setup;
    end
end

%% SP DIT [3]
for i=1:size(RS_dist,1)
    SP_DIT(i,1) = RS_dist(i,1);
    % In RESHO, disassociation threshold is changed considering velocity  
    % and session setup time
    SP_DIT(i,2) = ((RSS_out(1,2) - RS_dist(i,2) - 10) / v) - session_setup;
    if SP_DIT(i,2) > (Max_expire_time + session_setup)
        SP_DIT(i,2) = (Max_expire_time + session_setup);
    elseif SP_DIT(i,2) < session_setup
        SP_DIT(i,2) = session_setup;
    end
end

%% Graph
figure()   
a=plot(Exist_DIT(:,1), Exist_DIT(:,2),'-sk','MarkerSize',8, ...
    'LineWidth',0.7); hold on;
b=plot(RESHO_DIT(:,1), RESHO_DIT(:,2),'-vk','MarkerSize',8, ...
    'LineWidth',0.7); hold on;
c=plot(SP_DIT(:,1), SP_DIT(:,2),'-^k','MarkerSize',8, ...
    'LineWidth',0.7); hold on;
d=plot(PS_DIT(:,1), PS_DIT(:,2),'-xk','MarkerSize',8, ...
    'LineWidth',0.5); hold on;
axis([-74 -60 0.7 12]);
xlabel('RSSI (dBm)','fontsize',10,'fontweight','b');
ylabel('Data Interruption Time (s)','fontsize',10,'fontweight','b');
legend([a b c d],{'IEEE 802.11 [1]', 'RESHO [2]', 'SP [3]', 'PS eq. (9)'} ...
    , 'fontsize',11, 'Location', 'SOUTHEAST');

%% Clear
clear L P_r P_t RSS_out RS_dist W a avg_RTT b backoff Max_expire_time
clear c cts d d_0 data difs exp_slot fval i m mu n pe_data pe_rts pp ps ptr
clear rate rts session_setup sifs sigam slot tc temp0 temp1 temp2 trcd ts v 
clear x x0