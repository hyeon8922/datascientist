clear all; close all; clc;
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % 
%   File name:      Fig_4_Throughput.m                                    %
%   Last update:    April, 2016                                           %
%   Professor:     Jong-Moon Chung (Coressponding Author)                 %
%   Author:   Sungjin Shin, Donghyuk Han, Hyoungjun Cho                   %
%             Researcher / Engineer                                       %
%             Communications & Networking Lab (CNL)                       %
%             School of Electrical & Electronic Engineering               %
%             Yonsei University                                           %
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

%% IEEE 802.11 Variables
W=32;                                 % Min CW 
m=7;                                  % Retry limit
n=15;                                 % number of nodes
l_data=1550*8;                        % DATA size (bits)
l_rts=44*8;                           % RTS size (bits)
ts_dcf=l_rts+28+1+l_rts+28+1 ...      % Success time
    +l_data+28+1+l_rts+128+1;
tc=l_rts+28+l_rts+28+l_data+128;      % Fail time
te=l_rts+28+l_rts+28+l_data+128;      % Fail time
ts_basic = l_data+28+1+l_rts+128+1;
tc_basic = l_data+128;
te_basic = l_data+128;

%% IEEE 802.11 Equations
% Bit Error Rate
p_ber = [power(10,-6), power(10,-5.5), power(10,-5), power(10,-4.5), ...
    power(10,-4), power(10,-3.5), power(10,-3), power(10,-2.5) ...
    ,power(10,-2), power(10,-1.5),power(10,-1)]; 
for i=1:size(p_ber,2)
    pe_data(i,1) = 1 - power((1-p_ber(1,i)),l_data);
    pe_rts(i,1) = 1 - power((1-p_ber(1,i)),l_rts);
end
pe_cts=pe_rts; pe_ack=pe_rts;

for i=1:size(p_ber,2)
    x0 = [1; 1];
    % Equation for tau (probability that an UE transmits a RTS packet in a 
    % randomly chosen slot time and p (probability that a transmitted RTS 
    % packet encounters a collision
    [x(i,:),fval] = fsolve(@(x0)Bianchi_obfective_function(x0,n,W,m),x0);
    % conditional probability that at least one transmission occurs in a 
    % randomly chosen slot time
    ptr(i,1)=1-(1-x(i,1))^n;
    % conditional probability that this transmission is successful
    ps(i,1)=( (n*x(i,1)*power(1-x(i,1),n-1))/ptr(i,1) );
    % Basic [1-3]
    s_dcf(i,1)=ptr(i,1)*ps(i,1)*(1-pe_data(i,1))*l_data/ ( (1-ptr(i,1)) ...
        *50 + ptr(i,1)*ps(i,1)*(1-pe_data(i,1))*ts_basic + ptr(i,1) ...
        *(1-ps(i,1))*tc_basic + ptr(i,1)*ps(i,1)*pe_data(i,1) ...
        *te_basic);
    % RTS/CTS [1-3]
    s_dcf(i,2)=ptr(i,1)*ps(i,1)*(1-pe_rts(i,1))*l_data/ ...
        ((1-ptr(i,1))*50 + ptr(i,1)*ps(i,1)*(1-pe_rts(i,1))*ts_dcf ...
        + ptr(i,1)*(1-ps(i,1))*tc + ptr(i,1)*ps(i,1)*pe_rts(i,1)*te ...
        + ptr(i,1)*ps(i,1)*pe_rts(i,1)*te + ptr(i,1)*ps(i,1) ...
        *pe_rts(i,1)*pe_data(i,1)*ts_dcf);
    % Equation (10)
    s_dcf(i,3)=ptr(i,1)*ps(i,1)*(1-pe_rts(i,1))*l_data ...
        / (   (1-ptr(i,1))*50 + ptr(i,1)*(1-ps(i,1))*tc ...
        + ptr(i,1)*ps(i,1)*(1-pe_rts(i,1))*(1-pe_rts(i,1))*ts_dcf ...
        + ptr(i,1)*ps(i,1)*pe_rts(i,1)*te ...
        + ptr(i,1)*ps(i,1)*(1-pe_rts(i,1))*pe_rts(i,1)*te ...
        + ptr(i,1)*ps(i,1)*(1-pe_rts(i,1))*(1-pe_rts(i,1)) ...
        *(1-pe_data(i,1))*pe_rts(i,1)*ts_dcf   );
end

%% Graph
figure()   
a=semilogx(p_ber(1,:),s_dcf(:,1),'-sk','MarkerSize',8,'MarkerFaceColor'...
    ,'k', 'LineWidth',0.7);  hold on;                       % Basic [1-3]
b=semilogx(p_ber(1,:),s_dcf(:,2),'-sk','MarkerSize',8, 'LineWidth',0.7);
    hold on;                                                % RTS/CTS [1-3]
c=semilogx(p_ber(1,:),s_dcf(:,3),'-ok','MarkerSize',8, 'LineWidth',0.7);
    hold on;                                                % Equation (10)
axis([10^(-6) 10^(-1.5) -0.08 1]);
xlabel('BER','fontsize',10,'fontweight','b');
ylabel('Throughput (Mbps)','fontsize',10,'fontweight','b');
legend([c b a],{'PS eq. (10)', 'RTS/CTS [1-3]','Basic [1-3]'} ...
    , 'fontsize',11, 'Location','NORTHEAST');

%% Clear
clear W a b c fval i l_data l_rts m n pe_ack pe_cts tc_basic te te_basic
clear ts_basic x x0 p_ber pe_data pe_rts ps ptr tc ts_dcf
